package Day6;
import java.util.*;


public class bankAccount {
	private int balance;

    public bankAccount(int initialBalance)
     {
        this.balance = initialBalance;
    }

    public void deposit(double amount) 
    {
        balance += amount;
        
    }
    public void withdraw(double amount) 
    {
        if (amount <= balance) 
        {
            balance -= amount;
        } 
        else 
        {
            System.out.println("Insufficient funds.");
        }
        }
    public double getBalance() 
    {
        return balance;
    }

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
        System.out.print("Enter your initial balance: ");
        int a=sc.nextInt();
        bankAccount obj = new bankAccount(a);
        System.out.println("Initial balance: $" + obj.getBalance());
        System.out.println("enter the deposit amount");
        int b=sc.nextInt();
        obj.deposit(b);
        System.out.println("Balance after deposit: $" + obj.getBalance());
        System.out.println("enter the withdrawal amount");
        int c =sc.nextInt();
        obj.withdraw(c);
        System.out.println("Balance after withdrawal: $" + obj.getBalance());
        obj.withdraw(1500.00);
        System.out.println("Final balance: $" + obj.getBalance());

	}

}
