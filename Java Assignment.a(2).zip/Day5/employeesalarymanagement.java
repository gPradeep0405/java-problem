package Day5;
import java.util.*;

class Employee {
    String name;
    int id;
    double basicSalary;
    double allowances;

    // Default constructor
    Employee() {
    }

    // Parameterized constructor
    Employee(String name, int id, double basicSalary, double allowances) {
        this.name = name;
        this.id = id;
        this.basicSalary = basicSalary;
        this.allowances = allowances;
    }

    // Method to calculate gross salary
    double calculateGrossSalary() {
        return basicSalary + allowances;
    }

    // Method to display employee details
    void displayDetails() {
        System.out.println("Name: " + name);
        System.out.println("ID: " + id);
        System.out.println("Basic Salary: $" + basicSalary);
        System.out.println("Allowances: $" + allowances);
        System.out.println("Gross Salary: $" + calculateGrossSalary());
    }
}
public class employeesalarymanagement {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the number of Emoployee: ");
		int numEmployees=sc.nextInt();
		if(numEmployees==0) {
			System.out.println("No employees to manage: ");
			return;
		}
		Employee[] employees=new Employee[numEmployees];
		
		for(int i=0;i<numEmployees;i++) {
			sc.nextLine();
			System.out.println("entera details: ");
			System.out.print("Name:   ");
			String name=sc.nextLine();
			System.out.print("ID: ");
            int id = sc.nextInt();
			System.out.print("Basic Salary: ");
            double basicSalary = sc.nextDouble();

            System.out.print("Allowances: ");
            double allowances = sc.nextDouble();

            // Create an employee object and store it in the array
            employees[i] = new Employee(name, id, basicSalary, allowances);

		}
		 for (int i = 0; i < numEmployees; i++) {
	            System.out.println("\nDetails of employee " + (i + 1) + ":");
	            employees[i].displayDetails();
	        }

	        sc.close();

	}

}
