package Day5;
import java.util.*;
class Student{
	private String name;
	private double homegrade;
	private double finalgrade;
	
	public Student(String name, double homegrade, double finalgrade) {
		this.name=name;
		this.homegrade=homegrade;
		this.finalgrade=finalgrade;
	}
	
	public String getName() {
		return name;
	}
	
	public double gethomegrade() {
		return homegrade;
	}
	public double getFinalgrade() {
        return finalgrade;
    }

    public double calculateAverageGrade() {
        return (homegrade + finalgrade) / 2.0;
    }
}




public class grademanager {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a name: ");
		String name=sc.nextLine();
		System.out.print("Enter homework Grade: ");
		double homegrade=sc.nextDouble();
		System.out.print("Enter a final exm grade: ");
		double finalgrade=sc.nextDouble();
		
		Student student=new Student(name, homegrade, finalgrade);
		System.out.println("Student Name: "+student.getName());
		System.out.println("Homework Grade: "+student.gethomegrade());
		System.out.println("Final Exam Grade: "+student.getFinalgrade());
		System.out.println("Average Grade: "+student.calculateAverageGrade());

	}

}
